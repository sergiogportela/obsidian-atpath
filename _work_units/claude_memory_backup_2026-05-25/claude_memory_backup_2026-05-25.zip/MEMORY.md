# AtPath Project Memory

## Repo conventions

- **CLAUDE.md is always a symlink to AGENTS.md.** Never write to `CLAUDE.md` directly — always edit `AGENTS.md`. The symlink ensures both Codex/agents (AGENTS.md) and Claude Code (CLAUDE.md) read the same file.

## User preferences

- [Simplest/most reliable approach](feedback_approach.md) — prefer clean breaks, no backwards compat shims
- [Agent-driven verification](feedback_verification.md) — use browser agents and Perplexity, not manual test steps
- [Obsidian version check](feedback_obsidian_version.md) — don't use Info.plist, it shows installer version not app version
