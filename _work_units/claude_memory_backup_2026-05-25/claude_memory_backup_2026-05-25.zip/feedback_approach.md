---
name: User approach preferences
description: Sergio prefers simplest/most reliable solutions, clean breaks over backwards compat, agent-driven verification
type: feedback
---

Always go for the simplest, most reliable solution. Don't over-engineer.

**Why:** User explicitly states this as a core preference. Confirmed across multiple decisions (choosing Clerk over custom auth, mailto over request-access infrastructure, etc.)

**How to apply:** When presenting options, lead with the simplest. Avoid backwards-compatibility shims — user prefers clean breaks ("no one is using them, delete the old projects"). Use Perplexity agents liberally to verify approach simplicity before committing.
