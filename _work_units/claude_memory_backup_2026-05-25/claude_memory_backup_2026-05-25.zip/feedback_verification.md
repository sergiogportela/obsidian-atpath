---
name: Verification via agents
description: User wants automated verification using browser agents and Perplexity, not manual testing instructions
type: feedback
---

Verification should be done by agents (browser agent for UI testing, Perplexity for approach validation), not by listing manual test steps for the user.

**Why:** User explicitly said "that verification will be done by u with browser agent" and "call extra perplexity agent to confirm".

**How to apply:** After implementation, launch agents to verify the changes work. Use Perplexity to cross-check technical decisions before committing to an approach. Don't just list manual verification steps in plans.
