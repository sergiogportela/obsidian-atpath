---
name: Obsidian version check method
description: CFBundleShortVersionString shows installer version, not actual Obsidian app version — use About dialog or obsidian --version instead
type: feedback
---

Do not use `defaults read .../Info.plist CFBundleShortVersionString` to check Obsidian version — it returns the installer version (e.g., 1.7.7), not the actual app version (e.g., 1.12.7).

**Why:** The Obsidian.app bundle version in Info.plist reflects the Electron installer/wrapper, not the Obsidian application version which updates independently.

**How to apply:** When checking Obsidian version, use the CLI (`obsidian --version`) or ask the user to check About dialog.
